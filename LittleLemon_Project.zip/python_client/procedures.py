from connection import create_connection

conn = create_connection()
cursor = conn.cursor()

def AddBooking(customer_id, table_id, date, time):
    query = "INSERT INTO bookings (customer_id, table_id, booking_date, booking_time) VALUES (%s, %s, %s, %s)"
    cursor.execute(query, (customer_id, table_id, date, time))
    conn.commit()
    print("Booking added successfully.")

def CancelBooking(booking_id):
    query = "UPDATE bookings SET status='Cancelled' WHERE booking_id=%s"
    cursor.execute(query, (booking_id,))
    conn.commit()
    print("Booking cancelled.")

def UpdateBooking(booking_id, table_id=None, date=None, time=None):
    updates = []
    params = []
    if table_id:
        updates.append("table_id=%s")
        params.append(table_id)
    if date:
        updates.append("booking_date=%s")
        params.append(date)
    if time:
        updates.append("booking_time=%s")
        params.append(time)
    params.append(booking_id)
    query = f"UPDATE bookings SET {', '.join(updates)} WHERE booking_id=%s"
    cursor.execute(query, tuple(params))
    conn.commit()
    print("Booking updated.")

def GetMaxQuantity(table_id):
    query = "SELECT COUNT(*) FROM bookings WHERE table_id=%s AND status='Booked'"
    cursor.execute(query, (table_id,))
    result = cursor.fetchone()[0]
    print(f"Total bookings for table {table_id}: {result}")
    return result

def ManageBooking(customer_id, table_id, date, time):
    max_booked = GetMaxQuantity(table_id)
    if max_booked < 1:
        AddBooking(customer_id, table_id, date, time)
    else:
        print("Table is already booked at this time.")
