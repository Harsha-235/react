import mysql.connector

def create_connection():
    conn = mysql.connector.connect(
        host="localhost",
        user="yourusername",
        password="yourpassword",
        database="LittleLemon"
    )
    return conn
